package com.example.kentec.myapplicationmysql;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText qty, prodName, prodDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        qty = (EditText) findViewById(R.id.editTextQty);
        prodName = (EditText) findViewById(R.id.editTextProdName);
        prodDescription = (EditText) findViewById(R.id.editTextDescription);

    }
}
